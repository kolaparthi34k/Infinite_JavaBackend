package com.capgemini.sample.JunitExamples;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
public class CalccTest {

	@Before
	public void call()
	{
		System.out.println("First");
	}
	@Test
	public void mytest()
	{
		assertEquals(40, new Calc().add(10,30));
		
	}
	
	@After
	public void callme()
	{
		System.out.println("Last");
	}
}
