package com.capgemini.sample.JunitExamples;

import static org.junit.Assert.*;

import org.junit.Test;

public class AppTest 
    
{
    @Test
	public void testApp()
    {
    	System.out.println("display");
    	//assertTrue( true );
    }
}
