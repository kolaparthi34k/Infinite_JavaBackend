package com.capgemini.sample.JunitExamples;
import static org.junit.Assert.*;

import org.junit.Test;
public class Example1 {
	
	
	@Test
	public void display()
	{
		System.out.println("Junit");
	}
	
	@Test
	public void display1()
	{
		String g ="Srini";
		String g1 ="SriniK";
		
		assertEquals(g,g1);
	}

}
