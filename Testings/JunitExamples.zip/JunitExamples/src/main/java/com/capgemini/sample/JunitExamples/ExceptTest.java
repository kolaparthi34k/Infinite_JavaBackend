package com.capgemini.sample.JunitExamples;

public class ExceptTest {

	
	public static void testing()
	{
			int a=1/0;
	}
	
	public static void main(String...a)
	{
		testing();
	}
}
