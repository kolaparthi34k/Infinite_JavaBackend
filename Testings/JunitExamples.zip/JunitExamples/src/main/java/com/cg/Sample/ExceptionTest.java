package com.cg.Sample;

import org.junit.Test;

public class ExceptionTest {

	   String message = "Kolaparthi";	
	   
	   @Test(expected = ArithmeticException.class)
	   public void testPrintMessage() {	
		 int a=1/0;
	      System.out.println("Inside testPrintMessage()");     
	   }

	   @Test
	   public void testSalutationMessage() {
	      System.out.println("Inside testSalutationMessage()");
	      message = "Hi!";
	   }
	}